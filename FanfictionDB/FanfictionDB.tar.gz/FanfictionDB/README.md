FanfictionDB
============

Fanfiction Downloader and Library

Icon found @ http://www.iconsdb.com/royal-blue-icons/book-stack-icon.html

NOTE: Currently in the process of migrating the entire project to Python3
