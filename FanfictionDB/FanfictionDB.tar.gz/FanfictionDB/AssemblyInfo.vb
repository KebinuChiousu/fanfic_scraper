Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Fanfiction Website Scraper and Tracker")> 
<Assembly: AssemblyDescription("Downloads Chapters from Fanfiction Websites")> 
<Assembly: AssemblyCompany("Evolutionary Networking Designs")> 
<Assembly: AssemblyProduct("")> 
<Assembly: AssemblyCopyright("Copyright 2012 END")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("19330A17-5D22-4789-B357-77BE1F0F46CA")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("0.6.2.*")> 
